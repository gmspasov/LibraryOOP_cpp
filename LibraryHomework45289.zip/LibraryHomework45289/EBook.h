#ifndef EBOOK_H
#define EBOOK_H

#include "Book.h"


class EBook : public Book
{
public:
    /** Default constructor */
    EBook();

    /** Constructor with parameters*/
    EBook(char* title, unsigned number_of_pages, unsigned views, int size_of_the_book );

    /** Access views
     * \return The current value of views
     */
    unsigned Get_views() const
    {
        return views;
    }

    /** Set views
     * \param val New value to set
     */
    void Set_views(unsigned val)
    {
        views = val;
    }

    /** Access size_of_the_book
     * \return The current value of size_of_the_book
     */
    int Get_size_of_the_book() const
    {
        return size_of_the_book;
    }

    /** Set size_of_the_book
     * \param val New value to set
     */
    void Set_size_of_the_book(int val)
    {
        size_of_the_book = val;
    }

    /** Get the rating of the book */
    double Get_rating () const
    {
        if(views>200)
        {
            return 5.0;
        }
        return views/40.0;
    }

protected:

private:
    unsigned views; //!< Member variable "views"
    int size_of_the_book; //!< Member variable "size_of_the_book"
};

#endif // EBOOK_H
