#include "Book.h"
#include "cstring"


Book::Book()
{
    title=new char[strlen("NoTitleSet")+1];
    strcpy(title,"NoTitleSet");
}

Book::Book(char* t,unsigned n)
{
    title=new char[strlen(t)+1];
    strcpy(title,t);
    number_of_pages=n;
}

Book::~Book()
{
    delete[] title;
}

Book::Book(const Book& other)
{
    title=new char[strlen(other.Get_title())+1];
    strcpy(title,other.Get_title());
    \
    number_of_pages=other.Get_number_of_pages();
}


Book& Book::operator=(const Book& rhs)
{
    if (this == &rhs)
        return *this; // handle self assignment
    //assignment operator
    delete[] title;
    title=new char[strlen(rhs.Get_title())+1];
    strcpy(title,rhs.Get_title());
    number_of_pages=rhs.Get_number_of_pages();
    return *this;
}


bool Book::operator>(const Book& other)
{
    return hasLargerTitle(other.Get_title());
}

bool Book::operator<(const Book& other)
{
    return !(hasLargerTitle(other.Get_title()));
}

bool Book::hasLargerTitle(char* othersTitle) const
{
    if(!strcmp(title,"NoTitleSet"))
    {
        return false;
    }
    int i=0;
    int size_of_title=strlen(title);
    int size_of_othersTitle=strlen(othersTitle);
    int smaller;
    bool a;
    if(size_of_title>size_of_othersTitle)
    {
        smaller=size_of_othersTitle;
        a=1;
    }
    else
    {
        a=0;
        smaller=size_of_title;
    }
    while(i<smaller && title[i]==othersTitle[i])
    {
        ++i;
    }
    if((i==smaller && a)||(title[i]>othersTitle[i]))
    {
        return false;
    }
    else
    {
        return true;
    }

}


istream& operator>>(istream& input, Book& book)
{
    book.deleteTitle();
    char a [40];
    cout<<"Enter the name of the book"<<endl;
    input.getline(a,40);
    book.Set_title(a);
    cout<<book.Get_title()<<endl;
    unsigned b=0;
    cout<<"Enter the number of pages of the book"<<endl;
    input>>b;
    book.Set_number_of_pages(b);
    cout<<book.Get_number_of_pages()<<endl;
    return input;
}

