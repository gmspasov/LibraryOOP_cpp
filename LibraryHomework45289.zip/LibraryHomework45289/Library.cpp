#include "Library.h"
#include <algorithm>
#include <functional>
#include <array>
#include <iostream>
Library::Library()
{
    number_of_books=0;
    size_of_the_array=0;
}

Library::~Library()
{
    delete [] books;
}

Library::Library(const Library& other)
{
    copyBooks(other.Get_books(),other.Get_number_of_books());
}

Library& Library::operator=(const Library& rhs)
{
    if (this == &rhs)
        return *this; // handle self assignment
    //assignment operator
    delete [] books;
    number_of_books=0;
    size_of_the_array=0;
    copyBooks(rhs.Get_books(),rhs.Get_number_of_books());
    return *this;
}

void Library::copyBooks(Book* new_books, int new_number_of_books)
{
    size_of_the_array=2;

    while(size_of_the_array<new_number_of_books)
    {
        size_of_the_array*=2;
    }
    if(number_of_books)
    {
        delete [] books;
    }
    books=new Book[size_of_the_array];

    number_of_books=new_number_of_books;

    for(int i=0; i<number_of_books; ++i)
    {
        books[i]=new_books[i];
    }

}

void Library::sortByTitle()
{
    vector<Book> b;
    for(int i=0; i<number_of_books; ++i)
    {
        b.push_back(books[i]);
    }

    sort(b.begin(),b.end());

    delete [] books;
    books=new Book[number_of_books];
    for(int i=0; i<number_of_books; ++i)
    {
        books[i]=b.at(number_of_books-i-1);
    }
}

void Library::addBook(const Book& book)
{
    if(number_of_books>=size_of_the_array)
    {
        resize_array(size_of_the_array);
    }

    books[number_of_books]=book;
    number_of_books++;
    is_empty=0;
}

void Library::removeBook(unsigned n)
{
    if(n>number_of_books||n<1)
    {
        cout<<"No such position."<<endl;
    }
    else
    {
        books[n-1].deleteTitle();
        books[n-1].Set_number_of_pages(0);
        check_is_empty();
        Book* temp=new Book[number_of_books-1];
        for(int i=0; i<number_of_books; ++i)
        {
            int j=i;
            if(i==n-1)
            {
                continue;
            }
            if(i>=n)
            {
                j=i-1;
            }
            temp[j]=books[i];
        }
        delete [] books;
        int o=number_of_books;
        number_of_books=0;
        copyBooks(temp,o-1);
        delete [] temp;
    }
}

void Library::removeBook(char* t)
{
    bool a=0;
    for(int i=0; i<number_of_books; ++i)
    {
        if(!(strcmp(t,books[i].Get_title())))
        {
            books[i].deleteTitle();
            books[i].Set_number_of_pages(0);
            Book* temp=new Book[number_of_books-1];
            for(int n=0; n<number_of_books; ++n)
            {
                int j=n;
                if(n==i)
                {
                    continue;
                }
                if(n>i)
                {
                    j=n-1;
                }
                temp[j]=books[n];
            }
            delete [] books;
            int o=number_of_books;
            number_of_books=0;
            copyBooks(temp,o-1);
            a=1;
            delete [] temp;
        }
    }
    if(!a)
    {
        cout<<"No such book." <<endl;
    }
    else
    {
        check_is_empty();
    }
}

double Library::Get_mean_of_pages() const
{
    double sum_of_pages=0;
    if(is_empty)
    {
        return sum_of_pages;
    }

    for(int i=0; i<number_of_books; ++i)
    {
        sum_of_pages+=books[i].Get_number_of_pages();
    }
    return sum_of_pages/number_of_books;
}

const Book& Library::operator[](unsigned n)
{
    Book a;
    if(n>number_of_books||n<1)
    {
        return a;
    }
    return books[n-1];
}


void Library::resize_array(int old_size)
{
    if(!old_size)
    {
        old_size=2;
        books=new Book[2];
        size_of_the_array=2;
    }
    else
    {
        Book* temp=new Book[old_size];
        for(int i=0; i<old_size; ++i)
        {
            temp[i]=books[i];
        }
        delete [] books;
        books=new Book[old_size*2];
        for(int j=0; j<old_size; ++j)
        {
            books[j]=temp[j];
        }
        size_of_the_array=old_size*2;
    }
}

void Library :: print() const
{
    cout<<endl<<endl<<endl<<"-------------This are the books in the library:-------------- "<<endl<<endl<<endl;
    for(int i=0; i<number_of_books; ++i)
    {
        cout<<books[i].Get_title()<<endl;
    }
}
