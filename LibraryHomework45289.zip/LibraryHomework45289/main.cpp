#include <iostream>
#include "Book.h"
#include "EBook.h"
#include "Library.h"

using namespace std;


/*the program is a solution of this task:
Библиотека
Да се създаде клас Book, който да съдържа следните данни, характерни за една книга:
заглавие на книгата;
брой страници.
Да се създаде подходящ конструктор за Book, както и необходимите селектори и мутатори. Предефинирайте оператори:
за изход (<<);
за вход (>>);
оператори > и < (сравнява книги лексикографски по заглавие).
Да се създаде клас EBook (онлайн книга), който наследява класа Book. Като член-данни да се съдържат размера на книгата в байтове (int) и броя отваряния на книгата. Добавете необходимите мутатори, селектори и конструктор по зададени данни. Да се напише функция, която връща рейтинга на книгата чрез формулата:
ако броят на отварянията е над 200, рейтингът е 5;
иначе рейтингът е брой на отваряния / 40.
Да се създаде клас Library, който да съдържа динамичен масив от книги. Да има възможност за добавяне и махане на книга от масива, както и намиране на средното аритметично на броя страници на всички книги в масива. Предефинирайте оператор [], който да връща книга по поредния ѝ номер в масива. Напишете функция sortByTitle, която да сортира масива от книги по заглавията им.




created by Georgi M. Spasov 23.06.2019, 16.07
*/
int main()
{

    //testing the program
    Book a("Baltic Cuisine",3000);
    Book b("Captain Nemo",333);
    Book c("Dracula",402);
    Book d("Alice in Wonderland",304);
    Book e("The Adventures of Tom Sawyer",458);
    Book f("Misery",176);
    EBook g("Evgenii Onegin",322,201,12);
    EBook h("The Bible",4332,13,13);
    EBook i("Mein Kampf",792,313,44);
    EBook j("The Call of the Wild",400,110,4);
    EBook k("1001 nights",3743,21,68);


    cout<<endl<<"Pushkin's novel in poetry \"Evgenii Onegin\" has a rating of: "<<g.Get_rating()<<endl;
    cout<<endl<<"Jack London's novel \"The Call of the Wild\" has a rating of: "<<j.Get_rating()<<endl;

    Library littleLibrary;
    littleLibrary.addBook(a);
    littleLibrary.addBook(b);
    littleLibrary.addBook(c);
    littleLibrary.addBook(d);
    littleLibrary.addBook(e);
    littleLibrary.addBook(f);
    littleLibrary.addBook(g);
    littleLibrary.addBook(h);
    littleLibrary.addBook(i);
    littleLibrary.addBook(j);
    littleLibrary.addBook(k);
    littleLibrary.addBook(c);

        cout<<endl<<"The mean number of pages of the books in the library is : "<<littleLibrary.Get_mean_of_pages()<<endl;

    littleLibrary.print();
    littleLibrary.sortByTitle();
    cout<<"sorting the books"<<endl;

    Book l;
    cin>>l;
    cout<<"Adding the book "<<l.Get_title()<<endl;
    littleLibrary.addBook(l);
    littleLibrary.print();

    cout<<"Removing a book with name \"Dracula\" "<<endl;
    littleLibrary.removeBook("Dracula");


    cout<<"Removing the 7-th book. "<<"which is \" "<<littleLibrary[7].Get_title()<<"\" "<<endl;
    littleLibrary.removeBook(7);

    cout<<"Removing the 12-th book "<<endl;
    littleLibrary.removeBook(12);
    cout<<"sorting the books"<<endl;
    littleLibrary.sortByTitle();
    littleLibrary.print();

    cout<<endl<<"The fourth book in the library is "<< littleLibrary[4].Get_title()<<endl;
    cout<<endl<<"The mean number of pages of the books in the library is :  "<<littleLibrary.Get_mean_of_pages()<<endl;

    return 0;
}
