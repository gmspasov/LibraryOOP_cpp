#include "EBook.h"

EBook::EBook()
{
    views=0;
    size_of_the_book=0;
}

EBook::EBook(char* t,unsigned n, unsigned v, int s):Book(t,n)
{
views=v;
size_of_the_book=s;
}

