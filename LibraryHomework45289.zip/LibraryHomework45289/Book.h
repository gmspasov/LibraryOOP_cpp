#ifndef BOOK_H
#define BOOK_H
#include <iostream>
#include "cstring"
using namespace std;

class Book
{
public:
    /** Default constructor */
    Book();

    /**Constructor with parameters*/
    Book(char* title,unsigned number_of_pages);

    /** Default destructor */
    virtual ~Book();

    /** Copy constructor
     *  \param other Object to copy from
     */
    Book(const Book& other);

    /** Assignment operator
     *  \param other Object to assign from
     *  \return A reference to this
     */
    Book& operator=(const Book& other);

    /** Access number_of_pages
     * \return The current value of number_of_pages
     */
    unsigned Get_number_of_pages() const
    {
        return number_of_pages;
    }

    /** Set number_of_pages
     * \param val New value to set
     */
    void Set_number_of_pages(unsigned val)
    {
        number_of_pages = val;
    }

    /** Access title
     * \return The current value of title
     */
    char* Get_title() const
    {
        return title;
    }

    /** Set title
     * \param val New value to set
     */
    void Set_title(char* val)
    {
        deleteTitle();
        title=new char[strlen(val)+1];
        strcpy(title,val);
    }

    /**deletes title */
    void deleteTitle()
    {
        delete[] title;
    }

    /** prints the book title and number of pages */
    friend ostream& operator <<(ostream& output, const Book& thiss);


    /**initialize the book*/
    friend istream& operator >>(istream& input, Book&);

    /**compares two books with > */
    bool operator >(const Book&);

    /**compares two books with < */
    bool operator <(const Book&);

    /** returns if the book has "larger" alphabetically title than other's title */
    bool hasLargerTitle(char* othersTitle) const;



protected:

private:
    unsigned number_of_pages; //!< Member variable "number_of_pages"
    char* title; //!< Member variable "title"
};

#endif // BOOK_H
