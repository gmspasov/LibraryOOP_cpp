#ifndef LIBRARY_H
#define LIBRARY_H
#include "Book.h"

class Library
{
public:
    /** Default constructor */
    Library();

    /** Default destructor */
    virtual ~Library();

    /** Copy constructor
     *  \param other Object to copy from
     */
    Library(const Library& other);

    /** Assignment operator
     *  \param other Object to assign from
     *  \return A reference to this
     */
    Library& operator=(const Library& other);

    /** Access books
     * \return The current value of books
     */
    Book* Get_books() const
    {
        return books;
    }


    /** Access number_of_books
     * \return The current value of number_of_books
     */
    int Get_number_of_books() const
    {
        return number_of_books;
    }

    /** Set number_of_books
     * \param val New value to set
     */
    void Set_number_of_books(int val)
    {
        number_of_books = val;
    }

    /** Access size_of_the_array
     * \return The current value of size_of_the_array
     */
    int Get_size_of_the_array() const
    {
        return size_of_the_array;
    }

    /** Set size_of_the_array
     * \param val New value to set
     */
    void Set_size_of_the_array(int val)
    {
        size_of_the_array = val;
    }

    /** Checks if the library is empty*/
    bool check_is_empty()
    {
        for(int i=0;i<number_of_books;++i)
            {
            if(books[i].Get_number_of_pages()!=0)
                {
                is_empty=0;
            return 0;
                }
            }
            is_empty=1;
        return true;
    }

    /**copies the arrays of books*/
    void copyBooks(Book* books, int number_of_books);

    /**sorts the book alphabetically by title*/
    void sortByTitle();

    /**adds a book to the array*/
    void addBook(const Book& book);

    /**removes book on position n-1 if it is in the array books */
    void removeBook(unsigned n);

    /**removes ONE book with title t if it is in the array books */
    void removeBook(char* t);

    /** returns the mean number of the number of pages of the books in the library*/
    double Get_mean_of_pages() const;

    /** returns the book which is on position n-1 in books */
    const Book& operator[](unsigned n);

    /** resizes the array (doubles its size) */
    void resize_array(int old_size);

    /**prints all the book titles in the library*/
    void print() const;

protected:

private:
    Book* books; //!< Member variable "books"
    int number_of_books; //!< Member variable "number_of_books"
    int size_of_the_array; //!< Member variable "size_of_the_array"
    bool is_empty; //!<Member variable "is_empty"
};

#endif // LIBRARY_H
